import React, {useEffect,useRef, useState} from 'react';

    export const fetchPocimon = async (url, arr) => {
        let nextURL='';
        let isLoading=false;
        try {
            
            const response = await fetch(url);
            const json = await response.json();
             nextURL=json.next;
            let result=json.results;
            result.forEach(element => {
                arr.push(element);
           
                          });
             isLoading=true;
            // console.log('arr is:'+arr )
        } catch (error) {
            console.log("error", error);
        }
       // let returnArray=[arr, isLoading, nextURL];
       const returnObj = {
        isLoading: isLoading,
        nextURL: nextURL,
        pocimonsArray: arr
        };
    


  return returnObj;
}
