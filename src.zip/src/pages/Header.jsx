import React, { useState } from "react";
import logo from '../img/image4.png';



export default function Header({isLoading , resultArray, setDisplayArray}) {
    
  let count=0;
  const [nameInput, setName]= useState('');
  let displayArray=[];
  
  const handleInput = () => {
    if(isLoading){
      
      resultArray.forEach(e => {
        if (e.name.includes(nameInput)){
          displayArray.push(e);
        }
      });
      setDisplayArray(displayArray);

    }
  } ;
  const handleGetAll = () => {
    setDisplayArray(resultArray);
  }

  return (
    <div>
      <img src={logo} alt="" style={{ marginBottom: '38px', marginTop:'37px', width:'387px', height:'140' }}/>
      <br />
      <input type="text" style={{borderRadius: '8px', width: '341px', height:'36'}} placeholder="Search pocimon" onChange={e => setName(e.target.value)}  />
      <button style={{borderRadius: '8px'}} onClick={handleInput}> search </button>
      <button style={{borderRadius: '8px'}} onClick={handleGetAll}> get All </button>
     
    </div>

  )
}
