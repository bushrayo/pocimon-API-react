import React from 'react';
import './modal.css';

export default function Modal({setOpenModal,thePocimonJson}) {
  return (
    <div className="modalBackground">
      <div className="modalContainer">

        <div className="titleCloseBtn">
          <button onClick={() => {setOpenModal(false);}}> X </button>
        </div>

        <div className="half">
          <div className='part1' >
              <h4 className="order">#{thePocimonJson.order}</h4>
              <div className='part1a'>
                <img className="img" src={thePocimonJson.sprites.back_default} alt="pocimon pic" />
                <div className="title">
                  <h1> {thePocimonJson.name} </h1>
                </div>
              </div>
              
          </div>    
          <div>
            <h5 style={{border: '1px dotted blue', height:'70%', width: '1px', borderLeft: '4px solid black'}}></h5>         
          </div>     

          <div className="footer">
            <div className='description'>
              <h2>Description:</h2>
              <p>This is <span > {thePocimonJson.name}</span>  pocimon, His base experience is: {thePocimonJson.base_experience}. </p>
              
            </div>
            <p>...................................</p>
            <div className='stats'>
               <h2>stats:</h2>
              <h3>height: {thePocimonJson.height}</h3> 
              <h3>weight: {thePocimonJson.weight}</h3>
            </div>
              
          </div>

        </div>


        
     </div>
   </div>
       
  ); }
