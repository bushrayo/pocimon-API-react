import React, { useEffect, useState } from "react";
import Modal from "./Modal"

export default function Card(props) {
    let name= props.obj.name;
    let url= props.obj.url;
    let img='';

    const [theJson, setTheJson] = useState({});
    const [isLoading, setIsLoading] = useState(false);
    const [isOpenModal, setOpenModal] = useState(false);
    
    useEffect(() => {
    const fetchData = async () => {
        try {
            const response = await fetch(url);
            const json = await response.json();
            setTheJson(json);
            setIsLoading(true);
                        
        } catch (error) {
            console.log("error", error);
           }
     };
     fetchData();
    }, []);

    if(isLoading){
        img=theJson.sprites.back_default;
    }
  
    function handleClick(){
        setOpenModal(true);
    }

    return (
                 
          <div>
            <div onClick={()=> handleClick()} style={{borderRadius: '8px', border: '1px solid black', width: '267px', height:'238px', margin: '10px 10px 10px 10px', backgroundColor:'#f0f5f5' }}>
                <h4 style={{marginBottom: '0px', display: 'flex',justifyItems: 'flex-start' }}>#{theJson.order}</h4>
                <h4 style={{marginBottom: '0px'}}> {name} </h4>
                <img src={img} alt="pocemonPic" style={{width: '164px', height: '150px'}}/>
            </div>
            {isOpenModal && <Modal setOpenModal={setOpenModal} thePocimonJson={theJson} />}
        </div>
      )
    }
    