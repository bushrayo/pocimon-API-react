import React,{useState,useEffect,useRef} from 'react';
import  {fetchPocimon}  from '../fechPocimon';


export default function Footer({nextUrl, setNextUrl, resultArray}) {
  
  const [isClicked, setIsClicked] = useState(false);

  let result=[];
  let getInformation={};
  let pocimonsArr=[];
  let nextURL='';
  let isLoading=false;
    
  useEffect(() => {
   
      if(isClicked){
        fetchPocimon(nextUrl, resultArray).then(
          function(value) {           
            getInformation=value;
            pocimonsArr=getInformation.pocimonsArray;
            nextURL=getInformation.nextURL;
            isLoading=true;
            setNextUrl(nextURL);
            
           },
          function(error) { console.log('error'); }
        );
        setIsClicked(false);

      }
         
  }, [isClicked]);
   
const handleClick = () => {
  setIsClicked(true);
  };

    return (
      <div>
          <button onClick={handleClick} style={{marginBottom: '86px' , width: '210px' , height:'36px',borderRadius: '8px'}} > load more... </button>
      </div>
           
    )
  }
