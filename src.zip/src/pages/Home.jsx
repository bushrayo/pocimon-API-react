import React, {useEffect,useRef, useState} from 'react';
import Header from './Header';
import Content from './Content';
import Footer from './Footer';
import { fetchPocimon } from '../fechPocimon';


function Home() {
  const url='https://pokeapi.co/api/v2/pokemon?limit=20&offset=0';
  const [resultArray, setResultArray] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [displayArray, setDisplayArray] = useState('');
  const [nextUrl, setNextUrl] = useState('');

  const shouldFetch = useRef(true);
  let getInformation={};
  

    useEffect(() => {
    if(shouldFetch.current){
      console.log('in Home');
      
      
      fetchPocimon(url, resultArray).then(
        function(value) {           
          getInformation=value;
          setResultArray(getInformation.pocimonsArray);
          setDisplayArray(getInformation.pocimonsArray);
          setNextUrl(getInformation.nextURL);
          setIsLoading(true);
         },
        function(error) { console.log('error'); }
      );
    
    }
    return () => {
      shouldFetch.current=false;
    }
    
      
  }, []);
  
  
  
  return isLoading? (
    <div className="App">

      <Header isLoading={isLoading} resultArray={resultArray} setDisplayArray={setDisplayArray}  />
      <Content isLoading={isLoading} displayArray={displayArray} />
      <Footer nextUrl={nextUrl} setNextUrl={setNextUrl} resultArray={resultArray} />
       

    </div>
  ): (<></>);
}

export default Home;
