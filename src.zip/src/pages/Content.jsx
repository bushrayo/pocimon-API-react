import React, { useEffect, useState } from "react";
import Card from "./Card";


export default function Content({isLoading , displayArray}) {
  return isLoading ? (
    <div style={{ display:'flex', justifyContent: 'center', flexWrap: 'wrap'  }}>
        {
          displayArray.map((pocimon) => (
          <Card obj={pocimon}/> 
          ))
        }
        
      </div>
     ): <div>is loading ...</div>
}

