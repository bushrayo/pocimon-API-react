//import React from "react";



const url='https://pokeapi.co/api/v2/pokemon?limit=20&offset=0';
 // let result=fetchData();
  
 export const fetchData = async () => {
      try {
          const response = await fetch(url);
          const json = await response.json();
          return json.results;
         
         
      } catch (error) {
          console.log("error", error);
          }
     };
   

  
  